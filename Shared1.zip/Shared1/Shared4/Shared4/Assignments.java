Assignments
____________________________________________________________________________
DAY 1: 
	Reading and Practice
	Linux Pocket Guide Till Page 63

DAY 2: 
	Reading and Practice
	Linux Pocket Guide Till Page 131

DAY 3: 
	Reading and Practice Git Commands
		Git Study Material
	
	Practical Assignments
	____________________________________________________________________________
	Simulate Branching WorkFlow As A Project Workflow
		Master, Dev and Testing Branch

	Simulate Branching Workflow As A Developer
		Dev Branch Is Developer Branch
		Implement Feature with Various Ideas and Approaches
			Use Branching To Maintain Your Ideas Implementation

DAY 4: 
	ASSIGNMENT 1
	____________________________________________
	Write Sum Function In C Language

	// Which Will Return Valid SUM For ANY X, Y
	// Otherwise Print Can't Calculate SUM

	int sum(int x, int y) {


	}

	ASSIGNMENT 2
	____________________________________________
	Write Sum Function In C Language

	// Which Will Return Valid SUM For ANY X, Y
	// Otherwise RETURN ERROR

	int sum(int x, int y) {

	}

	PROVE YOUR CODE IS RIGHT OR WRONG
		REASON WITH DEFINITION
			DATA TYPE

	Fundamental Thinking
	____________________________________________________________________________
	OverFlow And Underflow
		Fundamental Part of System [Finite]

	What is Far More Fundamental 
		Value or Type
		Variable


	Language Designer Thinking
	____________________________________________________________________________
		Language Design
			Ballee Balleee Language
		
		Data Type
			int In Balleee Ballee
				Which Design You Will Prefer and Why?

	READING ASSIGNMENT [ MUST ]
	____________________________________________________________________________
		Data Type Chapter1
			Programming In C, 2nd Edition
				By Kernigham and Denish Ritchie.

	____________________________________________________________________________
	Prove Following Identities Are True/False?
		Prove Int In C = Int In Java?
		Prove Int In Java = Int In C++?
		Prove Int In C = Int In C++?

	Prove Above Results For float, double, long, char also

	Floating Point Numbers
	____________________________________________________________________________
	https://en.wikipedia.org/wiki/Single-precision_floating-point_format
	https://en.wikipedia.org/wiki/Double-precision_floating-point_format

++++++++++++++++++++++++++++++++++++++++++++++++++++++
--> RAISE HAND IF DONE READING AND PRACTICE ASSIGNMENT 
++++++++++++++++++++++++++++++++++++++++++++++++++++++
