package learnJava;

import java.util.Random;

public class Variables {

	public static void main(String[] args) {
		int total = 0;
		int i = 0, count;

		System.out.println(total);
		System.out.println(i);
		System.out.println(count);
	}
}