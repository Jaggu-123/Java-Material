#include <stdio.h>

// Searching For Definition of Function
	// Implementation of Function

// int printf(char something[]) {
// 	return 0;
// }

int main() {

	printf("\nHello World!...");

	return 0;
}

