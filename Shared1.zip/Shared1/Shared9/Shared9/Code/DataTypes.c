#include <stdio.h>

int playWithDataTypes() {
	int a 		= 20;
	int *ptr 	= &a;
	char *cptr 	=  (char *) ptr;
	float *fptr =  (float *) cptr;
	double *dptr = (double *) fptr;
	void *vptr 	 = (void *) dptr;

	printf("\nValues Are: %d %d", a, *(int *) vptr);
	printf("\n%ul %ul %ul %ul %ul", ptr, cptr, fptr, dptr, vptr);
	printf("\n%d %d %d %d %d", *ptr, *cptr, *fptr, *dptr);
	printf("\n%d %d %d %d %d %d", *ptr, *(int *)cptr, *(int *)fptr, *(int *)dptr, *(int *)vptr);
}

int playWithDataTypesOnceMore() {
	int a 		= 20;
	int *ptr 	= &a;
	char *cptr 	=  (char *) ptr;
	float *fptr =  (float *) cptr;
	double *dptr = (double *) fptr;
	void *vptr 	 = (void *) dptr;

	printf("\n ptr :%ld %ld", ptr, ++ptr);
	printf("\ncptr :%ld %ld", cptr, ++cptr);
	printf("\nfptr :%ld %ld", fptr, ++fptr);
	printf("\ndptr :%ld %ld", dptr, ++dptr);
	printf("\nvptr :%ld %ld", vptr, ++vptr);
}

int playWithArrays() {
	int something[10] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } ;

	void * 
	// Can We Store Heterogenous Types Data in Same C Array?
}

int main() {
	printf("\nFunction: playWithDataTypes");
	playWithDataTypes();

	printf("\nFunction: playWithDataTypesOnceMore");
	playWithDataTypesOnceMore();

	// printf("\nFunction: \n");
	// printf("\nFunction: \n");
	// printf("\nFunction: \n");
}

