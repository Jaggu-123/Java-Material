
Zoom Meeting
____________________________________________________________________________
https://www.google.com/url?q=https%3A%2F%2Fus02web.zoom.us%2Fmeeting%2Fregister%2FtZMldO2qqz4sG9HnrWF1mwfLYWTeE1wuKlXt
https://us02web.zoom.us/j/87834255615

Sunday Link:
https://us02web.zoom.us/meeting/register/tZUsceytqz8tEtJJCEVOAN88SL7IUTptg2x-

Monday Link:
https://us02web.zoom.us/meeting/register/tZIvfu6rrzwuGNMuFOhV_vMAN1-2XSsTjsIX

5th May
https://us02web.zoom.us/meeting/register/tZUvcu6rrjMvHdeRtfp-0Equve-3S8nJUrYt

6th May
https://us02web.zoom.us/meeting/register/tZIuduyhrDosHd1LInaBVEUjdYZtZymEQWLB

7th May
https://zoom.us/meeting/register/tJwvdeytrjMsHtUsw8ioyLt0js0owhJEA74k

Apart from this, I've shared a calendar invite for tomorrow's sync up with
Coordination Mechanisms
____________________________________________________________________________
	GitHub URL	: https://github.com/techhue/FlipkartJEDI
	Questions 	: https://tinyurl.com/yc4d532p
	Discussions	: https://tinyurl.com/ydylpn64
	Thinking Exercises: https://tinyurl.com/y7knepv8
	

	Must Share Your PRIMARY GMAIL ID
	Documents Will Be Shared ONLY ON your PRIMARY GMAIL ID


















Coordination Mechanisms
____________________________________________________________________________
	GitHub URL	: https://github.com/techhue/FlipkartJEDI
	Questions 	: https://tinyurl.com/yc4d532p
	Discussions	: https://tinyurl.com/ydylpn64
	Discussions Doc: https://tinyurl.com/y8y6lc3a

	Must Share Your PRIMARY GMAIL ID
	Documents Will Be Shared ONLY ON your PRIMARY GMAIL ID


Contacts
____________________________________________________________________________
	vaibhav.sharma@flipkart.com	
 	anandsaurav100@gmail.com
