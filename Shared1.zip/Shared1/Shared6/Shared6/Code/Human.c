#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];

	// This Management
	void (*dance)();
} Human;

// This is Outside
void doBhangra() {
	printf("\nBalleeee Balleeee... Oye Hoyee!!!\n");
}

int main() {
								 // Initliase
	Human h = { 10, "Ram Singh", doBhangra }; // Constructor Call

	printf("\nHuman : %d, %s\n", h.id, h.name ); // State Directly
	
	// C++ | Java
	h.dance();
	
	// Message Passing : h recieves message dance
	// dance message getting mapped to method doBhangra()
}
